package Cab;

public class CabInfo {

	/* variables */
	private float x;
	private float y;
	private float distanceToEnd;
	private String goTo;
	private String status;
	
	/**
	 * Constructor without parameters
	 */
	public CabInfo(){
		x = 0.0f;
		y = 0.0f;
		distanceToEnd = 0.0f;
		goTo = "";
		status = "";
	}
	
	/**
	 * Constructor with 5 parameters
	 * @param x
	 * @param y
	 * @param dist
	 * @param goTO
	 * @param status
	 */
	public CabInfo(float x, float y, float dist, String goTO, String status){
		this.setX(x);
		this.setY(y);
		this.setDistanceToEnd(dist);
		this.setGoTo(goTO);
		this.setStatus(status);
	}

	public float getX() {
		return x;
	}

	public void setX(float x) {
		this.x = x;
	}

	public float getY() {
		return y;
	}

	public void setY(float y) {
		this.y = y;
	}

	public float getDistanceToEnd() {
		return distanceToEnd;
	}

	public void setDistanceToEnd(float distanceToEnd) {
		this.distanceToEnd = distanceToEnd;
	}

	public String getGoTo() {
		return goTo;
	}

	public void setGoTo(String goTo) {
		this.goTo = goTo;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}
	
}
