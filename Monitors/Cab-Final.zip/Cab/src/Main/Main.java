package Main;


import java.io.File;

import Connect.ClientSocket;
import Connect.Connect;


public class Main {

	/* main */
	public static void main(String[] args) {
		
		/* new connection */
		Connect connection = new Connect();
		connection.start();
	}
}
