package Ihm;

import java.awt.Graphics2D;
import java.awt.geom.Rectangle2D;

import Map.Area;
import Map.Vertex;

public class PaintVertices {

	private float tailleVertice = 20.0f;
	private float margeX = 0.0f;
	private float margeY = 0.0f;
	
	/**
	 * Constructor without parameters
	 */
	public PaintVertices(){
		
	}
	
	/**
	 * Constructor with parameters
	 * @param area
	 * @param graph
	 * @param w
	 * @param h
	 */
	public PaintVertices(Area area, Graphics2D graph, float w, float h){
		for(Vertex object : area.getMap().getVertices()){
			float xVertice = object.getX() * w;
			float yVertice = object.getY() * h;
			
			/* resize if the vertex is outside the window */
			if (xVertice >(w-tailleVertice)){
				xVertice = w-tailleVertice;
			}
			if (yVertice > (h-tailleVertice)){
				yVertice = h-(tailleVertice*2.1f);
			}
			
			float x = xVertice;
			float y = yVertice;
			
			Rectangle2D rect1 = new Rectangle2D.Double((double)x, (double)y, (double)tailleVertice, (double)tailleVertice);
			
			/* square's inside */
			graph.fill(rect1);
			
		}
	}
}
