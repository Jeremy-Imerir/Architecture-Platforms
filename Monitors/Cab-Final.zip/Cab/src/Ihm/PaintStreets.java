package Ihm;

import java.awt.Graphics2D;
import java.awt.Shape;
import java.awt.geom.Line2D;

import Map.Area;
import Map.Streets;
import Map.Vertex;

public class PaintStreets {

	/**
	 * Constructor without parameters
	 */
	public PaintStreets(){
		
	}
	
	/**
	 * Constructor with 2 parameters
	 * @param area
	 * @param graph
	 */
	public PaintStreets(Area area, Graphics2D graph){
		
		/* declaration of variables */
		float x1 = 0;
		float y1 = 0;
		float x2 = 0;
		float y2 = 0;
		
		/* course of streets object */
		for(Streets object : area.getMap().getStreets()){
			/* get the differents points in path */
			String point1 = object.getPath().get(0);
			String point2 = object.getPath().get(1);
			
			/* course of vertex object */
			for(Vertex objVertex : area.getMap().getVertices()){
				
				String nameVertex = objVertex.getName();
				int compare1 = nameVertex.compareTo(point1);
				int compare2 = nameVertex.compareTo(point2);
				
				/* test if object name equal point1 */
				if(compare1 == 0){
					x1 = objVertex.getX();
					y1 = objVertex.getY();
				}

				/* test if object name equal point2 */
				else if(compare2 == 0){
					x2 = objVertex.getX();
					y2 = objVertex.getY();
				}				
			}
			/* draw the line between the two points */
			Line2D l = new Line2D.Float(x1, y1, x2, y2);
			graph.draw(l);
		}
	}
}
