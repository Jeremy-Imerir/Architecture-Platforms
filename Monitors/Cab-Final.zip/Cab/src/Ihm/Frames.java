package Ihm;

import java.awt.Dimension;

import javax.swing.JFrame;
import javax.swing.JPanel;

import Map.Area;

public class Frames extends JFrame {

	private Paint paint;
	private int widthFrame ;
	private int heightFrame;
	
	public Frames(Area a){
		
		/* get fenetre size */
		Dimension size = java.awt.Toolkit.getDefaultToolkit().getScreenSize();
		this.widthFrame = (int)size.getWidth();
		this.heightFrame = (int) size.getHeight() - 50;	/* Probleme of vertical size */
		
		JFrame frame = new JFrame("Cab " + a.getName());
		System.out.println(a.getMap().getVertices());
		paint = new Paint(a, this.widthFrame, this.heightFrame);
		
		/* add paint in frame*/
		frame.add(paint);

		/* frame's parameters */
		frame.setSize(this.widthFrame, this.heightFrame);
		frame.setResizable(false);
		frame.setVisible(true);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
}
