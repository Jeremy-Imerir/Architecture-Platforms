package Ihm;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.Shape;
import java.awt.Stroke;
import java.awt.geom.Line2D;

import Map.Area;
import Map.Streets;
import Map.Vertex;

public class PaintStreets {

	/**
	 * Constructor without parameters
	 */
	public PaintStreets(){
		
	}
	
	/**
	 * Constructor with 2 parameters
	 * @param area
	 * @param graph
	 */
	public PaintStreets(Area area, Graphics2D graph, float w, float h){
		
		/* declaration of variables */
		float x1 = 0;
		float y1 = 0;
		float x2 = 0;
		float y2 = 0;
		
		float echellex = 0.984f ;//20 * 1 / w; // 20 décallage en x pour les carrés
		float echelley = 0.947f ;//40 * 1 / h; // 40 décallage en y pour les carrés 
		
		/* course of streets object */
		for(Streets object : area.getMap().getStreets()){
			/* get the differents points in path */
			String point1 = object.getPath().get(0);
			String point2 = object.getPath().get(1);
			
			/* course of vertex object */
			for(Vertex objVertex : area.getMap().getVertices()){
				
				String nameVertex = objVertex.getName();
				boolean compare1 = nameVertex.equals(point1);
				boolean compare2 = nameVertex.equals(point2);
				
				/* test if object name equal point1 */
				if(compare1){
					
					x1 = objVertex.getX();
					y1 = objVertex.getY();
					
					if (x1 > echellex){
						x1 = echellex;
					}
					if (y1 > echelley){
						y1 = echelley;
					}
					x1 = x1 * w;
					y1 = y1 * h;
					System.out.println("Name: " + point1 + " - valeur de x1: " + x1 + " - valeur de y1: " + y1);
				}

				/* test if object name equal point2 */
				else if(compare2){
					
					x2 = objVertex.getX();
					y2 = objVertex.getY();
					
					
					if (x2 > echellex){
						x2 = echellex;
					}
					if (y2 > echelley){
						y2 = echelley;
					}
					x2 = x2 * w;
					y2 = y2 * h;
					
					System.out.println("Name: " + point2 + " - valeur de x2: " + x2 + " - valeur de y2: " + y2);
				}
				// sauvegarde de l'épaisseur du trait
				Stroke s = graph.getStroke();
				// trait épais
				graph.setStroke(new BasicStroke(2));
				graph.setColor(Color.red);
				/* draw the line between the two points */
				Line2D l = new Line2D.Float(x1, y1, x2, y2);
				graph.draw(l);
			}
		}
	}
}
