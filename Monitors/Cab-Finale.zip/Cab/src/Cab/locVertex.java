package Cab;

public class locVertex {

	/* variable */
	private String area;
	private String locationType;
	private String location;
	
	/**
	 * Constructor without parameters
	 */
	public locVertex(){
		
	}

	
	public String getArea() {
		return area;
	}

	public void setArea(String area) {
		this.area = area;
	}

	public String getLocationType() {
		return locationType;
	}

	public void setLocationType(String locationType) {
		this.locationType = locationType;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}
	
}
