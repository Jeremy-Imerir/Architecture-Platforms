package Connect;

import java.io.IOException;
import java.util.ArrayList;

import org.codehaus.jackson.JsonParseException;
import org.codehaus.jackson.map.JsonMappingException;
import org.codehaus.jackson.map.ObjectMapper;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import Cab.CabInfo;
import Ihm.Frames;
import Map.Area;

public class ClientJSON {

	/* variables */
	private String ip;
	private String port;
	private int numberClient;
	private int jsonNumber;
	private int jsonCab;
	private ArrayList<Area> areaNumberClient = new ArrayList<>();
	private CabInfo infoCab = new CabInfo();
	
	/**
	 * Constructor without parameters
	 */
	public ClientJSON(){
		
	}
	
	/**
	 * Constructor with parameters
	 * @param ip
	 * @param port
	 */
	public ClientJSON(String ip, String port){
		this.setIp(ip);
		this.setPort(port);
	}
	
	
	/**
	 * Decode JSON send by HTTP
	 * @param message
	 */
	public String HTTP_JSON(String message){
		
		/* creating objects and JSONParser */
        JSONParser parser = new JSONParser();
        JSONObject jsonObject = null;
        
        String msg = null;
        
        try {
	    	jsonObject = (JSONObject) parser.parse(message);

	    	/* allocation of variables */
	    	this.setIp(jsonObject.get("IP").toString());
	    	this.setPort(jsonObject.get("port").toString());
	    	msg = "ws://"+ getIp() + ":" + getPort() ;
	    	
	    	/* display IP and PORT */
	    	System.out.println("L'ip est: " + this.ip);
	    	System.out.println("Le port est: " + this.port);
	        
        } catch (org.json.simple.parser.ParseException e) {
            e.printStackTrace();
            System.out.println(e.getMessage());
        }
        /* return msg */
        return msg;
	}
	
	
	/**
	 * Decode JSON send by WebSocket
	 * @param message
	 * @throws ParseException 
	 * @throws IOException 
	 * @throws JsonMappingException 
	 * @throws JsonParseException 
	 */
	public void webSocketJSON(String message) throws ParseException, JsonParseException, JsonMappingException, IOException{
		
		/* creating objects and JSONParser JsonObject */
        JSONParser parser = new JSONParser();
        JSONObject jsonObject = null;
        
        ObjectMapper mapper = new ObjectMapper();
        
        jsonNumber = jsonCab = 0;
        /* test JSON or not */
        try{
        	jsonObject = (JSONObject) parser.parse(message);
        	
        	/* client number */
        	try{
    	    	this.numberClient = ((Long)jsonObject.get("clientNumber")).intValue() - 1;
    	    	jsonNumber = 1;
    	    	
        	}catch (Exception e){
        	}
        	try{
    	    	jsonObject.get("cab");
    	    	jsonCab = 1;
        	}catch (Exception e){
        	}
        }catch (Exception e){
    	}
        
        if(jsonNumber == 1){
        	/* add differents area in an array of object */
	        for (JSONObject o: (ArrayList<JSONObject>) jsonObject.get("areas")){
		    	Area area = mapper.readValue(o.toString(),Area.class);
		    	this.areaNumberClient.add(area);
	        }
	        
	        /* create windows according to the numberClient */
	        System.out.println(areaNumberClient.get(numberClient).getName());
	    	Frames frame = new Frames(this.areaNumberClient.get(numberClient));
	    	
        }else{
        	/* add JSON cab in an array of object*/
        	if(jsonCab == 1){
        		for (JSONObject o: (ArrayList<JSONObject>) jsonObject.get("cab")){
    		    	CabInfo infoCab = mapper.readValue(o.toString(),CabInfo.class);
    		    	System.out.println();
    	        }
        	}	
        }
	}

	/**
	 * Get ip
	 * @return
	 */
	public String getIp() {
		return ip;
	}
	
	/**
	 * Set ip
	 * @param ip
	 */
	public void setIp(String ip) {
		this.ip = ip;
	}
	
	/**
	 * Get port
	 * @return
	 */
	public String getPort() {
		return port;
	}
	
	/**
	 * String port
	 * @param port
	 */
	public void setPort(String port) {
		this.port = port;
	}
}
